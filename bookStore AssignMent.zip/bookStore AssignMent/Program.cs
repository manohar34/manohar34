﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookStor_Assignment
{

    class Book
    {
        public int bookId;
        public string bookName;
        public string author;
        public double price;
        public string description;
        public long ISBNCode;

        public Book(int bookId, string bookName, string author, double price, string description, long ISBNCode)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.author = author;
            this.price = price;
            this.description = description;
            this.ISBNCode = ISBNCode;
        }

        public override string ToString()
        {
            return $"Book Id : {bookId}; Book Name : {bookName}; author : {author}; price:{price}; Description : {description}; ISBN Code:{ISBNCode}";
        }
    }

    
    class Program
    {
        public static int num;

        //public static int num = Convert.ToInt32(Console.ReadLine());
        static void displayBook(ArrayList arr)
        {
            foreach (Book item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            ArrayList proArr = new ArrayList {
                new Book(101, "Here, There And EveryWhere", "Sudha Murthy",234,"Here, There and Everywhere, which is a collection of 22 short stories woven from the event-filled life of the computer scientist, philanthropist and author Sudha Murty, she expresses her special bond with her brother and renowned astrophysicist, Shrinivas Kulkarni.",9780143444343),
                new Book(102, "Fear Not: Be Strong","Swami Tathagatananda", 456,"A presentation of Swami Vivekananda's Message of strength and fearlessness by the resident swami of the Vedanta Society of New York.", 9788175054035),
                new Book(103, "The White Tiger","Aravind Adiga", 88,"The Secret of His Success. Balram Halwai, the narrator of Aravind Adiga's first novel, “The White Tiger,” is a modern Indian hero. In a country inebriated by its newfound economic prowess, he is a successful entrepreneur", 9781848878082),
                new Book(104, "Wings Of Fire","Apj Abdulkalam", 124,"An Autobiography of APJ Abdul Kalam (1999), former President of India. It was written by Dr. ... Dr. Kalam examines his early life", 9788173711466)

            };
            
            

            




            Console.WriteLine("Press 1 : add Book ");
            Console.WriteLine("Press 2 : delete Book");
            Console.WriteLine("Press 3 : Display");
            Console.WriteLine("press 4 : For Exit");

            int bookIndex = 0;
            bool isContain = proArr.Contains(proArr[bookIndex]);
            // public int num;
            do
            {
                Console.WriteLine();
                Console.WriteLine("Enter number according to your display choice");
                num = Convert.ToInt32(Console.ReadLine());
                switch (num)
                {

                    case 1:
                        {
                            proArr.Add(new Book(103, "The White Tiger", "Aravind Adiga", 88, "The Secret of His Success. Balram Halwai, the narrator of Aravind Adiga's first novel, “The White Tiger,” is a modern Indian hero. In a country inebriated by its newfound economic prowess, he is a successful entrepreneur", 9781848878082));
                            Console.WriteLine("After Adding to Book Details");
                            foreach (var item in proArr)
                            {
                                Console.WriteLine(item);
                            }
                            break;
                        };
                    case 2:
                        {
                            Console.WriteLine("Enter Book id to delete : ");
                            int bookId = Convert.ToInt32( Console.ReadLine());
                            foreach (Book item in proArr)
                            {
                                if (item.bookId == bookId)
                                {
                                     bookIndex = proArr.IndexOf(item);

                                }

                            }

                            if (isContain)
                            {
                                proArr.Remove(bookIndex);
                                displayBook(proArr);
                            }


                            break;
                }


                    case 3:
                        {
                            Console.WriteLine("Enter Book id value you want to edit : ");
                            int bookId = Convert.ToInt32( Console.ReadLine());

                            foreach (Book item in proArr)
                            {
                                if (item.bookId == bookId)
                                {
                                    Console.WriteLine("Enter bookId : ");
                                    int newbookId = Convert.ToInt32( Console.ReadLine());
                                    item.bookId = newbookId;

                                }
                            }
                            displayBook(proArr);
                            break;

                        }
                    case 4:
                        {
                            displayBook(proArr);


                        }
                        break ;
                }
            } while (num != 4);
            ;

            int num1 = 3; // 23 will assigned to num
            Object Obj = num1; // Boxing
            Console.WriteLine("value type : " + num1);
            Console.WriteLine("Reference type : " + Obj);

            num1 = 6;

            int num2 = (int)(Obj); //un Boxing
            Console.WriteLine("un boxing value : " + num2);
            Console.WriteLine( "After Assigning New value : " + num1);
            Console.ReadLine();
        }
    }
}
//The process of Converting a Value Type (char, int etc.) to a Reference Type(object) is called Boxing.
//Boxing is implicit conversion process in which object type (super type) is used.