myApp.controller("bookDeleteController",function($scope,bookManage){
    $scope.BookArr=bookManage.getBookDetails();
    $scope.deleteBookEventHandler=function(bookToBeDeleted)
    {
        bookManage.deleteBook(bookToBeDeleted);
        
    }

})