myApp.service("bookManage",function(){
    this.bookDetails=[
        { bookId: "B01", bookName: "Here, There And EveryWhere",author: "Sudha Murty", price: "Rs188", ISBNcode: 9780143444343, description: "Here, There and Everywhere, which is a collection of 22 short stories woven from the event-filled life of the computer scientist, philanthropist and author Sudha Murty, she expresses her special bond with her brother and renowned astrophysicist, Shrinivas Kulkarni.", bookImage:'C:\\Users\\mk60276\\Pictures\\Saved Pictures\\sudhamurthy.jpg' },
        { bookId: "B02", bookName: "Fear Not: Be Strong ",author: "Swami Tathagatananda", price: "Rs88", ISBNcode: 9788175054035, description: "A presentation of Swami Vivekananda's Message of strength and fearlessness by the resident swami of the Vedanta Society of New York. Vivekananda's stirring words roused not only the nation of India, but many in the west who were glad to see that religion could be uplifting in one's personal life", bookImage:'C:\\Users\\mk60276\\Pictures\\Saved Pictures\\fear Not.jpg' },
        { bookId: "B03", bookName: "The White Tiger",author: "Aravind Adiga", price: "Rs170", ISBNcode: 9781848878082, description: "The Secret of His Success. Balram Halwai, the narrator of Aravind Adiga's first novel, “The White Tiger,” is a modern Indian hero. In a country inebriated by its newfound economic prowess, he is a successful entrepreneur, a self-made man who has risen on the back of India's much-vaunted technology industry.",bookImage:'C:\\Users\\mk60276\\Pictures\\Saved Pictures\\whiteTiger.jpg' },
        { bookId: "B04", bookName: "Wings Of Fire",author: "Dr. Abdul Kalam and Arun Tiwari", price: "Rs150", ISBNcode: 9788173711466, description: "An Autobiography of APJ Abdul Kalam (1999), former President of India. It was written by Dr. ... Dr. Kalam examines his early life, effort, hardship, fortitude, luck and chance that eventually led him to lead Indian space research, nuclear and missile programs.",bookImage:'C:\\Users\\mk60276\\Pictures\\Saved Pictures\\wingsofFire.jpg'}
        ];



    this.getBookDetails=function()
    {
        return this.bookDetails;
    }
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }
    

    this.editBook = function(book) {
        return this.bookDetails[book];
    }

    console.log(this.bookDetails);
    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    }

})
